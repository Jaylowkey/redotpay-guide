PAYGO x RedotPay — vídeos tutoriais

Copie a pasta videos/ para a raiz do repositório Jaylowkey/redotpay-guide.
Os caminhos finais devem ser:
videos/cartao-virtual.mp4
videos/cartao-fisico.mp4
